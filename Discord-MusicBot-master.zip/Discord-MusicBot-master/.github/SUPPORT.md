# Seeking support?

We only use this issue tracker for bug reports and feature request. We are not able to provide general support or answer questions in the form of GitHub issues.

For general questions about the Music Bot and use please use the dedicated support channels in our Discord server: https://discord.gg/sbySMS7m3v

Any issues that don't directly involve a bug or a feature request will likely be closed and redirected.
